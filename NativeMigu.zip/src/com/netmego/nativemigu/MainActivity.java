package com.netmego.nativemigu;

import java.io.File;
import java.util.List;

import com.anysdk.framework.PluginWrapper;
import com.netmego.miguyouxinative.AnySDK_Manager;
import com.netmego.miguyouxinative.MiguSDKFactory;
import com.netmego.miguyouxinative.MiguSDKFactory.BillingListener;
import com.netmego.miguyouxinative.MiguSDKFactory.ExitGameListener;

import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {
	Activity thisActivity;
	Button payButton1, payButton2, payButton3, payButton4, payButton5;
	String payAlias = "";
	
	String AnySDK_AppKey = "4A495B5E-15CA-2250-9079-F6FA00D64431";
	String AnySDK_AppSecret = "67159a17dc7161950abcc034074bef8b";
	String AnySDK_privateKey = "EEE8C19E3CF09FDF3E840052C1646E22";
	String AnySDK_oauthLoginServer = "http://oauth.anysdk.com/api/OauthLoginDemo/Login.php";
	
	String MM_appID = "300008983717";
	String MM_appkey = "D964AE38E23A967B4EB0B05129A59BD9"; 
	String CompanyName = "杭州指老虎网络科技有限公司";
	String QAPhone = "57182877709"; 
	String AppName = "NativeSDKTest"; 	
	
	private boolean isAppForeground = true;
	
	boolean PromptExitInGame;
	
	private Handler postHandler = new Handler(); 
	
	BillingListener MainListener;

	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		thisActivity = this;
		payButton1 = (Button) findViewById(R.id.button1);
		payButton1.setOnClickListener(button1_OnClickListener);
		payButton2 = (Button) findViewById(R.id.button2);
		payButton2.setOnClickListener(button2_OnClickListener);
		payButton3 = (Button) findViewById(R.id.button3);
		payButton3.setOnClickListener(button3_OnClickListener);
		payButton4 = (Button) findViewById(R.id.button4);
		payButton4.setOnClickListener(button4_OnClickListener);
		payButton5 = (Button) findViewById(R.id.button5);
		payButton5.setOnClickListener(button5_OnClickListener);
		
        OnInit();
		
	}
	
	private OnClickListener button1_OnClickListener = new OnClickListener() {
		@Override
		public void onClick(View v) 
		{
			OnBuy( "001", "001", "Buy 1000 Gold", "1" );
		}
	};

	private OnClickListener button2_OnClickListener = new OnClickListener() {
		@Override
		public void onClick(View v) {
			OnBuy( "002", "002", "Buy 2000 Gold", "2" );
		}
	};

	private OnClickListener button3_OnClickListener = new OnClickListener() {
		@Override
		public void onClick(View v) {
			AboutUs(thisActivity);
			}
	};

	private OnClickListener button4_OnClickListener = new OnClickListener() {
		@Override
		public void onClick(View v) {
			viewMoreGames();
		}
	};

	private OnClickListener button5_OnClickListener = new OnClickListener() {
		@Override
		public void onClick(View v) {
			exit();
		}
	};
	
	@SuppressLint("NewApi") public boolean isAppOnForeground() 
	{
		ActivityManager activityManager = (ActivityManager) getApplicationContext()
				.getSystemService(Context.ACTIVITY_SERVICE);
		
		String packageName = getApplicationContext().getPackageName();
		
		List<RunningAppProcessInfo> appProcesses = activityManager.getRunningAppProcesses();
		if (appProcesses == null)
			return false;
		
		for (RunningAppProcessInfo appProcess : appProcesses) 
		{
			if (appProcess.processName.equals(packageName)
					&& appProcess.importance == RunningAppProcessInfo.IMPORTANCE_FOREGROUND) 
			{
				return true;
			}
		}
		
		return false;
	}
	 
	@Override
	protected void onStop() 
	{
		super.onStop();
		if ( MiguSDKFactory.getInstance() != null)
			MiguSDKFactory.getInstance().Stop(this);
		if(!isAppOnForeground())
		{
			isAppForeground = false;
		}
	}
	 
	@Override
	protected void onRestart() 
	{
		// TODO Auto-generated method stub
		super.onRestart();
		System.out.println("onRestart");
	}
	 
	@Override
	protected void onResume() 
	{
		super.onResume();
		
		if ( MiguSDKFactory.getInstance() != null)
			MiguSDKFactory.getInstance().Resume(this, isAppForeground);
		
		if(!isAppForeground)
		{
			isAppForeground = true;			
		}
	}
	
	@Override
	public void onPause()
	{
		super.onPause();
		
		if ( MiguSDKFactory.getInstance() != null)
			MiguSDKFactory.getInstance().Pause(this);
		
		if(!isAppOnForeground())
		{
			isAppForeground = false;
		}
	}

	// #2. 초기화 함수 
	public void OnInit()
	{
		System.out.println("Migu SDK init :" + AppName + ":"  + CompanyName);

		MainListener = new BillingListener()
		{
			@Override
			public void onPurchaseSucceed(String item) 
			{
				System.out.println("Migu Buy Success :" + item);
			}
			
			@Override
			public void onPurchaseInfo(String item, String msg) 
			{
				System.out.println("Migu Buy Info :" + item + ":" + msg);
			}
			
			@Override
			public void onPurchaseFailed(String item, String msg) 
			{
				System.out.println("Migu Buy Failed :" + item + ":" + msg);
			}
			
			@Override
			public void onPurchaseCanceld(String item, String msg) 
			{
				System.out.println("Migu Buy Canceled :" + item + ":" + msg);
			}
		};
		
		postHandler.post( new Runnable()
		{
			public void run()
			{
				MiguSDKFactory.init(
						MainActivity.this, MainListener,
						AnySDK_AppKey, AnySDK_AppSecret, AnySDK_privateKey, AnySDK_oauthLoginServer,
						MM_appID, MM_appkey,
						CompanyName, QAPhone, AppName );
			}
		});
	}
	
	// #3. 결제 신청
	public void OnBuy( final String smsPayItem, final String vaccode, final String props, final String money )
	{
		System.out.println("san wang on buy :" + smsPayItem);
		
		postHandler.post( new Runnable()
		{
			public void run()
			{
				MiguSDKFactory.getInstance().pay(MainActivity.this, smsPayItem, vaccode, props, money, MainListener, true);
			}
		});
	}

	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data){
		super.onActivityResult(requestCode, resultCode, data);
		
		if ( AnySDK_Manager.getInstance() != null && AnySDK_Manager.getInstance().Initialized )
			PluginWrapper.onActivityResult(requestCode, resultCode, data);
	}
	
	 @Override
	 protected void onDestroy() {
		 super.onDestroy();
		 if ( MiguSDKFactory.getInstance() != null)
			 MiguSDKFactory.getInstance().Destroy(this);
	 };
	 	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) 
	{
	    if (keyCode == KeyEvent.KEYCODE_BACK && MiguSDKFactory.getInstance() != null) 
	    {
	    	PromptExitInGame = false;
	    	MiguSDKFactory.getInstance().exitGame(MainActivity.this, new ExitGameListener() 
	    	{
	    		@Override
	    		public void onExitGameConfirmExit() 
	    		{
	    			MainActivity.this.exit();
	    		}
	
	    		@Override
	    		public void onExitGameCancelExit() 
	    		{
	    		}
	          
	    		@Override
	    		public void onExitGameInGame()
	    		{
	    			PromptExitInGame = true; 
	    		}
	    	});
    	
	    	if ( PromptExitInGame == true )
	    		return super.onKeyDown(keyCode, event);
    	
	    	return true;
	    }
	    
	    return super.onKeyDown(keyCode, event);
	}    
	       
  	public void exit()
  	{
  		if ( MiguSDKFactory.getInstance() != null )
		postHandler.post( new Runnable()
		{
			public void run()
			{
		    	MiguSDKFactory.getInstance().exitGame(MainActivity.this, new ExitGameListener() 
		    	{
		    		@Override
		    		public void onExitGameConfirmExit() 
		    		{
		    			System.exit(0);
		    		}
		
		    		@Override
		    		public void onExitGameCancelExit() 
		    		{
		    		}
		          
		    		@Override
		    		public void onExitGameInGame()
		    		{
		    		}
		    	});
			}
		});
  	}

  	public void exitGame()
  	{
  		MainActivity.this.exit();
  	}
	  	
    public int CheckMobile()
    {
    	if ( MiguSDKFactory.getInstance() == null )
    	{
    		return -1;
    	}
    	
    	return MiguSDKFactory.getInstance().getMobileOperatorType(); 
    }
    
    public void viewMoreGames()
    {
    	if ( MiguSDKFactory.getInstance() == null )
    		return;
    	
    	MiguSDKFactory.getInstance().viewMoreGames(MainActivity.this);
    }
	
    public boolean isMusicEnabled()
    {
    	if ( MiguSDKFactory.getInstance() == null )
    		return true;
    	
    	return MiguSDKFactory.getInstance().isMusicEnabled();
    }

	public void screenShotShare(final String filepath)
	{
    	if ( MiguSDKFactory.getInstance() == null )
    		return;
    	
		System.out.println("Brandon : scr path" + filepath);
    	MiguSDKFactory.getInstance().doScreenShotShare(MainActivity.this, Uri.fromFile(new File(filepath)));
	}
    
	public void AboutUs(Context context)
	{
		showDialog(context, "关于", "应用名称:" + AppName + "\n应用类型:手游\n公司名称:" + CompanyName + "\n客服电话:" + QAPhone + "\n版本号:1.00" );
	}
	
	public void showDialog(Context context, String title, String msg) {
        final String curMsg = msg;
        final String curTitle = title;
        final Context __context = context;

        postHandler.post( new Runnable()
		{
            @Override
            public void run() {
                new AlertDialog.Builder(__context)
                .setTitle(curTitle)
                .setMessage(curMsg)
                .setPositiveButton("Ok", 
                        new DialogInterface.OnClickListener() {
                            
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                
                            }
                        }).create().show();
            }
        });
    }
	
	
}
