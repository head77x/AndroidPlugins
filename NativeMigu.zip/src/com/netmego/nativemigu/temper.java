package com.netmego.nativemigu;

import com.netmego.miguyouxinative.MiguSDKFactory;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.netmego.nativemigu.MainActivity;

public class temper extends Activity
{
	private Handler postHandler = new Handler(); 
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{		
		super.onCreate(savedInstanceState);
		
		Intent intent;
/*
		intent = new Intent(this, MainActivity.class);
		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		this.startActivity(intent);

		finish();
*/		
		
		switch (MiguSDKFactory.getMobileOperatorMe(this)) 
		{
			case BILL_CMGD:
				try
				{
					intent = new Intent(this, cn.cmgame.billing.api.GameOpenActivity.class);
					intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					this.startActivity(intent);
					
					finish();
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			break;
			case BILL_DIANXIN:
				Intent dianxinintent = new Intent(this, com.netmego.miguyouxinative.DianXinLogoSplash.class);
				dianxinintent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				this.startActivity(dianxinintent);
				
				Handler dianxinhandler = new Handler()
				{
					public void handleMessage(Message msg)
					{
						Intent intent = new Intent(temper.this, MainActivity.class);
						intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
						temper.this.startActivity(intent);
						
						finish();
					}
				};
				
				dianxinhandler.sendEmptyMessageDelayed(0, 2000);
			break;
			case BILL_UNICOM:
				try
				{
					Intent unicomintent = new Intent(this, com.unicom.dcLoader.welcomeview.class);
					unicomintent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					this.startActivity(unicomintent);
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			break;
			case BILL_CMMM:
				Intent MM = new Intent(this, MainActivity.class);
				MM.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				this.startActivity(MM);
				
				finish();
			break;
			default:
				Intent ring = new Intent(this, com.netmego.miguyouxinative.MiguLogoSplash.class);
				ring.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				this.startActivity(ring);
				
				Handler ringhandler = new Handler()
				{
					public void handleMessage(Message msg)
					{
						Intent intent = new Intent(temper.this, MainActivity.class);
						intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
						temper.this.startActivity(intent);
						
						finish();
					}
				};
				
				ringhandler.sendEmptyMessageDelayed(0, 2000);
/*				
				try
				{
					intent = new Intent(this, MainActivity.class);
					intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					this.startActivity(intent);
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
*/				
			break;
		}
		
		finish();
	}
}
