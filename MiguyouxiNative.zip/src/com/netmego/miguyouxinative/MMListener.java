package com.netmego.miguyouxinative;

import java.util.HashMap;

import com.netmego.miguyouxinative.MiguSDKFactory.BillingListener;

import mm.purchasesdk.OnPurchaseListener;
import mm.purchasesdk.Purchase;
import mm.purchasesdk.PurchaseCode;

public class MMListener implements OnPurchaseListener /* CMM */
{
	BillingListener MasterListener;
	public String tryPay;
	public String tryMoney;

	public MMListener(BillingListener _listener) 
	{
		System.out.println("Brandon : MM Listner maked");
		
		MasterListener = _listener;
	}
	
	/**
	* CMCC_MM Listener
	*/
	@Override
	public void onAfterApply() {
		System.out.println("Brandon : MM onAfterApply");
	
	}
	
	@Override
	public void onAfterDownload() {
		System.out.println("Brandon : MM onAfterDownload");
	
	}
	
	@Override
	public void onBeforeApply() {
		System.out.println("Brandon : MM onBeforeApply");
	
	}
	
	@Override
	public void onBeforeDownload() {
		System.out.println("Brandon : MM onBeforeDownload");
	
	}
	
	@Override
	public void onInitFinish(int code) 
	{		
		System.out.println("Brandon : Init finish, status code = " + code + ":" + Purchase.getReason(code) );
	
	//mycontext.IAPInitResult(true);
	}
	
	@Override
	public void onBillingFinish(int code, HashMap arg1) 
	{
		System.out.println("Brandon : billing finish, status code = " + code);
		String result = "billing result :";
		String orderID = null;
		String paycode = null;
		String leftday = null;
		String tradeID = null;
		
		String ordertype = null;
	
		if (code == PurchaseCode.ORDER_OK || (code == PurchaseCode.AUTH_OK) ||(code == PurchaseCode.WEAK_ORDER_OK)) 
		{
			if (arg1 != null) 
			{
				leftday = (String) arg1.get(OnPurchaseListener.LEFTDAY);
				if (leftday != null && leftday.trim().length() != 0) {
					result = result + ",Left :" + leftday;
				}
				orderID = (String) arg1.get(OnPurchaseListener.ORDERID);
				if (orderID != null && orderID.trim().length() != 0) {
					result = result + ",OrderID :" + orderID;
				}
				paycode = (String) arg1.get(OnPurchaseListener.PAYCODE);
				if (paycode != null && paycode.trim().length() != 0) {
					result = result + ",Paycode:" + paycode;
				}
				tradeID = (String) arg1.get(OnPurchaseListener.TRADEID);
				if (tradeID != null && tradeID.trim().length() != 0) {
					result = result + ",tradeID:" + tradeID;
				}
				ordertype = (String) arg1.get(OnPurchaseListener.ORDERTYPE);
				if (tradeID != null && tradeID.trim().length() != 0) {
					result = result + ",ORDERTYPE:" + ordertype;
				}

				System.out.println("Brandon : " + orderID + ":" + paycode + ":" + tradeID + ":" + ordertype + ":" + code + Purchase.getReason(code));
				
				if (MasterListener != null) {
		    		try
		    		{
						MiguSDKFactory.getInstance().NoticeToMiguServer(
								tryPay, 
								tryMoney,
								"China Mobile MM");
		    		}
		    		catch(Exception ept)
		    		{
			    		System.out.println("Brandon : cannot logging :" + ept);
		    		}
					
					
					MasterListener.onPurchaseSucceed(tryPay);
					MasterListener.onPurchaseInfo(tryPay, result);
				}
	
			}
		}
		else 
		{
			result = "failed" + Purchase.getReason(code);
	
			MasterListener.onPurchaseFailed(tryPay, result);
		}
		
		System.out.println(result);
	}
	
	@Override
	public void onQueryFinish(int code, HashMap arg1) {
		System.out.println("Brandon : license finish, status code = " + code);
		String result = "onQueryFinish :";
		String orderID = null;
		String paycode = null;
		String leftday = null;
		if (code != PurchaseCode.QUERY_OK) 
		{
			result = "query failed :" + Purchase.getReason(code);
		} else {
			leftday = (String) arg1.get(OnPurchaseListener.LEFTDAY);
			if (leftday != null && leftday.trim().length() != 0) {
				result = result + ",Left :" + leftday;
			}
			orderID = (String) arg1.get(OnPurchaseListener.ORDERID);
			if (orderID != null && orderID.trim().length() != 0) {
				result = result + ",OrderID :" + orderID;
			}
			paycode = (String) arg1.get(OnPurchaseListener.PAYCODE);
			if (paycode != null && paycode.trim().length() != 0) {
				result = result + ",Paycode:" + paycode;
			}
		}
		
		System.out.println(result);
	//context.dismissProgressDialog();
	}
	
	
	@Override
	public void onUnsubscribeFinish(int code) {
	// TODO Auto-generated method stub
		String result = "��溫®퍜�옖竊�" + Purchase.getReason(code);
		System.out.println(result);
	//context.dismissProgressDialog();
	}
}
