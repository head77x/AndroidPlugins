package com.netmego.mmpay;

import java.util.HashMap;

import com.unity3d.player.UnityPlayerActivity;
import com.unity3d.player.UnityPlayer;

import mm.sms.purchasesdk.OnSMSPurchaseListener;
import mm.sms.purchasesdk.PurchaseCode;
import mm.sms.purchasesdk.SMSPurchase;

import android.os.Handler;
import android.os.Bundle;

public class MegoActivity extends UnityPlayerActivity
{
	public SMSPurchase purchase;

	private Handler postHandler = new Handler(); 
  	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
	}
	
	
	public void onResume() 
	{  
        super.onResume();  
    }
	
    public void onPause() 
    {  
    	super.onPause();  
    }  
        
	public void OnInit(final String AppID, final String AppKey, final String callbackGameObject, final String callbackFunc )
	{
		System.out.println("init" + AppID + ":"  + AppKey);

		postHandler.post( new Runnable()
		{
			public void run()
			{
				OnSMSPurchaseListener fff = new OnSMSPurchaseListener()
				{
					@Override
					public void onInitFinish(int code) 
					{
						UnityPlayer.UnitySendMessage(callbackGameObject, callbackFunc, code + "," + SMSPurchase.getReason(code) );
						System.out.println("Init finish, status code = " +code + ":" + SMSPurchase.getReason(code));
					}
					
					@Override
					public void onBillingFinish(int code, HashMap arg1) 
					{
					}					
				};
				
				purchase = SMSPurchase.getInstance();
				
				try {
					purchase.setAppInfo(AppID, AppKey);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				
				try {
					purchase.smsInit(MegoActivity.this, fff);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
	}
	
	public void OnBuy(final String Paycode, final String callbackGameObject, final String callbackFunc) 
	{
		System.out.println("on buy");

		postHandler.post( new Runnable()
		{
			public void run()
			{
				OnSMSPurchaseListener fff = new OnSMSPurchaseListener()
				{
					@Override
					public void onInitFinish(int code) 
					{
						UnityPlayer.UnitySendMessage(callbackGameObject, callbackFunc, code + "," + SMSPurchase.getReason(code) );
						System.out.println("Init finish, status code = " +code + ":" + SMSPurchase.getReason(code));
					}
					
					@Override
					public void onBillingFinish(int code, HashMap arg1) 
					{
						System.out.println("billing finish, status code = " +code + ":" + SMSPurchase.getReason(code));
						String paycode = null;
						String tradeID = null;

						String result = "DESC:" + SMSPurchase.getReason(code) + "," + code;
						
						if (code == PurchaseCode.ORDER_OK
								|| code == PurchaseCode.ORDER_OK_TIMEOUT) 
						{
							if (arg1 != null) 
							{
								result = result + ",";
								
								paycode = (String) arg1.get(OnSMSPurchaseListener.PAYCODE);
								
								if (paycode != null && paycode.trim().length() != 0) 
								{
									result = result + paycode;
								}
								
								result = result + ",";
								
								tradeID = (String) arg1.get(OnSMSPurchaseListener.TRADEID);
								
								if (tradeID != null && tradeID.trim().length() != 0) 
								{
									result = result + tradeID;
								}
							}
						} 

						UnityPlayer.UnitySendMessage(callbackGameObject, callbackFunc, result );
						System.out.println(result);
					}
				};
				
				try {
				    purchase.smsOrder(MegoActivity.this, Paycode, fff, "test!!!");
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
	}	

}
