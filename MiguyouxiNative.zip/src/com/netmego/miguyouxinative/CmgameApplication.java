package com.netmego.miguyouxinative;

import com.netmego.miguyouxinative.MiguSDKFactory;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;

public class CmgameApplication extends Application 
{
	@Override
	public void onCreate() 
	{
		super.onCreate();
		
		Context mine = this.getApplicationContext();
		
		switch (MiguSDKFactory.getMobileOperatorApp(mine))
		{
			case BILL_CMGD:				
				System.loadLibrary("megjb");
			break;
			case BILL_UNICOM:
				System.loadLibrary("megjb");
				
				Unicom_Manager.initSingleton(mine);
			break;
		}		
	}
	
}
